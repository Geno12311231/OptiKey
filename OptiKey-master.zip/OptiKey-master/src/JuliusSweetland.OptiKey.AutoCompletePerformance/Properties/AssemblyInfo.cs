﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("JuliusSweetland.OptiKey.AutoCompletePerformance")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("JuliusSweetland.OptiKey")]
[assembly: AssemblyCopyright("Licensed under the terms of the GNU GPL v3")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.0.0.0")]
