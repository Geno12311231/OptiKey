namespace JuliusSweetland.OptiKey.Enums
{
    public enum DockSizes
    {
        Collapsed,
        Full
    }
}
