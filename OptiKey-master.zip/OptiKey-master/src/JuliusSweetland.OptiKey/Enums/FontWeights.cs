﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum FontWeights
    {
        Thin, 
        Light, 
        Regular, 
        Medium, 
        Bold, 
        Black
    }
}
