﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum CharCategories
    {
        NewLine,
        Space,
        Tab,
        LetterOrDigitOrSymbolOrPunctuation,
        SomethingElse
    }
}
