﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum KeyDownStates
    {
        Up,
        Down,
        LockedDown
    }
}
