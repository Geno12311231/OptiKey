namespace JuliusSweetland.OptiKey.Enums
{
    public enum RunningStates
    {
        Running,
        Paused
    }
}
