﻿namespace JuliusSweetland.OptiKey.Enums
{
    public enum NotificationTypes
    {
        Normal,
        Error
    }
}
