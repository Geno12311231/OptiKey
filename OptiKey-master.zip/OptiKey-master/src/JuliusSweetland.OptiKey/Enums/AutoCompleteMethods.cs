namespace JuliusSweetland.OptiKey.Enums
{
    public enum AutoCompleteMethods
    {
        Basic,
        NGram
    }
}