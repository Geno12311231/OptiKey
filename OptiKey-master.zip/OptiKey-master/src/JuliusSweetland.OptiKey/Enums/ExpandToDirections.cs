namespace JuliusSweetland.OptiKey.Enums
{
    public enum ExpandToDirections
    {
        TopLeft,
        Top,
        TopRight,
        Right,
        BottomRight,
        Bottom,
        BottomLeft,
        Left
    }
}
