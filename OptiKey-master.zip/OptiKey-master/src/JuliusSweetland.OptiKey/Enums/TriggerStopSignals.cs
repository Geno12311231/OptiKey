namespace JuliusSweetland.OptiKey.Enums
{
    public enum TriggerStopSignals
    {
        NextHigh,
        NextLow
    }
}
