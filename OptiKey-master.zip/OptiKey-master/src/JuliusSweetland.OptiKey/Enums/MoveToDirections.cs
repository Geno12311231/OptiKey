namespace JuliusSweetland.OptiKey.Enums
{
    public enum MoveToDirections
    {
        TopLeft,
        Top,
        TopRight,
        Right,
        BottomRight,
        Bottom,
        BottomLeft,
        Left
    }
}
