﻿using System.Windows;

namespace JuliusSweetland.OptiKey.Models
{
    public class ThemeResourceDictionary : ResourceDictionary
    {
    }
}
