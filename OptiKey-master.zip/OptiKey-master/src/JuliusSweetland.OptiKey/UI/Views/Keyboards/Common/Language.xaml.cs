﻿using JuliusSweetland.OptiKey.UI.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Keyboards.Common
{
    /// <summary>
    /// Interaction logic for Language.xaml
    /// </summary>
    public partial class Language : KeyboardView
    {
        public Language()
        {
            InitializeComponent();
        }
    }
}
