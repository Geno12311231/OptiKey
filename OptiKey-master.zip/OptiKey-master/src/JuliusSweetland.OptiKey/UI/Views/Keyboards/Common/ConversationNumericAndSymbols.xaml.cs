﻿using JuliusSweetland.OptiKey.UI.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Keyboards.Common
{
    /// <summary>
    /// Interaction logic for ConversationNumericAndSymbols.xaml
    /// </summary>
    public partial class ConversationNumericAndSymbols : KeyboardView
    {
        public ConversationNumericAndSymbols()
        {
            InitializeComponent();
        }
    }
}
