using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Management
{
    /// <summary>
    /// Interaction logic for PointingAndSelectingView.xaml
    /// </summary>
    public partial class PointingAndSelectingView : UserControl
    {
        public PointingAndSelectingView()
        {
            InitializeComponent();
        }
    }
}
