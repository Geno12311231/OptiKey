using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Views.Management
{
    /// <summary>
    /// Interaction logic for OtherView.xaml
    /// </summary>
    public partial class OtherView : UserControl
    {
        public OtherView()
        {
            InitializeComponent();
        }
    }
}
