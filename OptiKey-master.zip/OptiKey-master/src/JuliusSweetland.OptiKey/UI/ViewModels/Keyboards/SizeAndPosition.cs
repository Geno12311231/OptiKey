﻿using System;
using JuliusSweetland.OptiKey.UI.ViewModels.Keyboards.Base;

namespace JuliusSweetland.OptiKey.UI.ViewModels.Keyboards
{
    public class SizeAndPosition : BackActionKeyboard
    {
        public SizeAndPosition(Action backAction) : base(backAction)
        {
        }
    }
}
