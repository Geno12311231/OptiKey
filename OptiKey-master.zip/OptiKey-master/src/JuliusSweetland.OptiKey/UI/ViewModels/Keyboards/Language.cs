﻿using System;
using JuliusSweetland.OptiKey.UI.ViewModels.Keyboards.Base;

namespace JuliusSweetland.OptiKey.UI.ViewModels.Keyboards
{
    public class Language : BackActionKeyboard
    {
        public Language(Action backAction) : base(backAction)
        {
        }
    }
}
