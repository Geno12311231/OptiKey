﻿using JuliusSweetland.OptiKey.UI.ViewModels.Keyboards.Base;

namespace JuliusSweetland.OptiKey.UI.ViewModels.Keyboards
{
    public class Alpha : Keyboard
    {
        public Alpha() : base(multiKeySelectionSupported:true)
        {
        }
    }
}
