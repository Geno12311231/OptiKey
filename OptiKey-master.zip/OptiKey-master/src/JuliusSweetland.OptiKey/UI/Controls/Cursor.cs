﻿using System.Windows.Controls;

namespace JuliusSweetland.OptiKey.UI.Controls
{
    public class Cursor : UserControl
    {
    }
}
